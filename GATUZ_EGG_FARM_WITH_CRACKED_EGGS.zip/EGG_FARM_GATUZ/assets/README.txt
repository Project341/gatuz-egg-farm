Project data folder.
